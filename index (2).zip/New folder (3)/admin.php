
<?php
require 'config.php';

$admin = require_login();

if ($admin['role'] !== 'admin') {
    http_response_code(403);
    exit('دسترسی غیرمجاز');
}

check_csrf();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = $_POST['user_id'] ?? '';
    $action = $_POST['action'] ?? '';

    $users = db_read('users');
    $found = false;

    foreach ($users as &$u) {

        if ($u['id'] !== $id) continue;

        if ($u['role'] === 'admin') break;

        if ($action === 'ban') {
            $u['banned'] = true;
            $found = true;
        }

        if ($action === 'unban') {
            $u['banned'] = false;
            $found = true;
        }

        if ($action === 'quota') {
            $gb = max(0.1, min(1000, (float)($_POST['quota_gb'] ?? 2)));
            $u['quota'] = (int)($gb * 1073741824);
            $found = true;
        }

        break;
    }

    unset($u);

    db_write('users', $users);

    flash(
        $found ? 'تغییرات ذخیره شد.' : 'عملیات انجام نشد.',
        $found ? 'success' : 'error'
    );

    go('admin.php');
}

$users = db_read('users');
$message = get_flash();
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>مدیریت کاربران | Paya</title>
<link rel="stylesheet" href="assets/style.css">
</head>

<body>
<div class="app">

<aside class="sidebar">
    <a href="dashboard.php" class="logo">
        <span class="brand-icon small-logo">P</span>
        <span><b>Paya</b><small>UPLOAD CENTER</small></span>
    </a>

    <div class="side-title">مدیریت</div>
    <a class="nav" href="dashboard.php">▦ داشبورد</a>
    <a class="nav active" href="admin.php">⚙ مدیریت کاربران</a>
</aside>

<main class="main">

<header class="topbar">
    <div>
        <div class="eyebrow">ADMIN CONTROL PANEL</div>
        <h1>مدیریت کاربران</h1>
        <p class="muted">مدیریت حساب‌ها، سهمیه و وضعیت کاربران</p>
    </div>

    <a href="dashboard.php" class="btn outline">بازگشت</a>
</header>

<?php if ($message): ?>
<div class="alert <?=h($message[1])?>">
    <?=h($message[0])?>
</div>
<?php endif; ?>

<section class="panel files-panel">

<div class="panel-heading">
    <div>
        <h2>لیست کاربران</h2>
        <p class="muted"><?=count($users)?> حساب ثبت‌شده</p>
    </div>
</div>

<div class="table-wrap">
<table>

<thead>
<tr>
<th>کاربر</th>
<th>وضعیت</th>
<th>حجم مصرفی</th>
<th>سهمیه</th>
<th>تغییر سهمیه</th>
<th>عملیات</th>
</tr>
</thead>

<tbody>

<?php foreach ($users as $u): ?>

<tr>

<td><b><?=h($u['username'])?></b></td>

<td>
<?php if (!empty($u['banned'])): ?>
<span style="color:#d94f62">مسدود</span>
<?php else: ?>
<span style="color:#20a879">فعال</span>
<?php endif; ?>
</td>

<td><?=h(format_size(used_storage($u['id'])))?></td>

<td><?=h(format_size($u['quota']))?></td>

<td>
<?php if ($u['role'] !== 'admin'): ?>

<form method="post" class="quota-form">
<input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
<input type="hidden" name="user_id" value="<?=h($u['id'])?>">
<input type="hidden" name="action" value="quota">

<input type="number"
name="quota_gb"
min="0.1"
max="1000"
step="0.1"
value="<?=h(round($u['quota']/1073741824,2))?>">

<button class="btn primary small">ذخیره</button>
</form>

<?php else: ?>
مدیر اصلی
<?php endif; ?>
</td>

<td>

<?php if ($u['role'] !== 'admin'): ?>

<form method="post"
onsubmit="return confirm('وضعیت این کاربر تغییر کند؟')">

<input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
<input type="hidden" name="user_id" value="<?=h($u['id'])?>">

<?php if (!empty($u['banned'])): ?>

<input type="hidden" name="action" value="unban">
<button class="btn primary small">Unban</button>

<?php else: ?>

<input type="hidden" name="action" value="ban">
<button class="btn small"
style="background:#fff0f1;color:#d94f62">
Ban User
</button>

<?php endif; ?>

</form>

<?php else: ?>
<span style="color:#929bb0">محافظت‌شده</span>
<?php endif; ?>

</td>

</tr>

<?php endforeach; ?>

</tbody>
</table>
</div>
</section>

<footer class="footer">
<span>Paya Upload Center</span>
<span>Admin Control Panel</span>
</footer>

</main>
</div>
</body>
</html>
