
<?php
require 'config.php';

if (current_user()) go('dashboard.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!preg_match('/^[a-zA-Z0-9_.-]{3,24}$/', $username)) {
        $error = 'نام کاربری باید ۳ تا ۲۴ کاراکتر باشد.';
    } elseif (strlen($password) < 8) {
        $error = 'رمز عبور باید حداقل ۸ کاراکتر باشد.';
    } else {
        $users = db_read('users');

        foreach ($users as $user) {
            if (strtolower($user['username']) === strtolower($username)) {
                $error = 'این نام کاربری قبلاً ثبت شده است.';
                break;
            }
        }

        if (!$error) {
            $users[] = [
                'id' => bin2hex(random_bytes(12)),
                'username' => $username,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'role' => 'user',
                'quota' => DEFAULT_QUOTA,
                'created_at' => date('c')
            ];

            db_write('users', $users);
            flash('حساب شما ساخته شد. اکنون وارد شوید.');
            go('login.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ثبت‌نام | Paya Upload Center</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="auth-page">
<div class="auth-card">
    <div class="brand-icon">P</div>
    <div class="eyebrow">JOIN PAYA CLOUD</div>
    <h1>ساخت حساب جدید</h1>
    <p class="muted">فضای ابری شخصی خودت را بساز.</p>

    <?php if ($error): ?>
        <div class="alert error"><?=h($error)?></div>
    <?php endif; ?>

    <form method="post" class="form-stack">
        <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
        <label>نام کاربری</label>
        <input name="username" required minlength="3" maxlength="24" placeholder="مثلاً paya_user">

        <label>رمز عبور</label>
        <input type="password" name="password" required minlength="8" placeholder="حداقل ۸ کاراکتر">

        <button class="btn primary full">ایجاد حساب ←</button>
    </form>

    <div class="auth-bottom">
        قبلاً ثبت‌نام کردی؟ <a href="login.php">وارد شو</a>
    </div>
</div>
</body>
</html>
