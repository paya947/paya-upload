
<?php
require 'config.php';

$token = $_GET['token'] ?? '';

foreach (db_read('files') as $file) {

    if (
        hash_equals($file['share_token'], $token) &&
        empty($file['deleted'])
    ) {
        $path = FILES_DIR . '/' . $file['stored_name'];

        if (!is_file($path)) break;

        header('Content-Type: application/octet-stream');
        header('Content-Length: ' . filesize($path));
        header(
            "Content-Disposition: attachment; filename*=UTF-8''" .
            rawurlencode($file['original_name'])
        );

        readfile($path);
        exit;
    }
}

http_response_code(404);
echo 'این لینک معتبر نیست یا فایل حذف شده است.';
