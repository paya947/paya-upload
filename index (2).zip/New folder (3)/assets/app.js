
const input = document.getElementById('fileInput');
const dropzone = document.getElementById('dropzone');
const fileNames = document.getElementById('fileNames');

if (input && dropzone) {

    function showFiles() {
        if (!input.files.length) {
            fileNames.textContent = 'حداکثر ۱۰۰ مگابایت برای هر فایل';
            return;
        }

        fileNames.textContent = Array.from(input.files)
            .map(file => file.name)
            .join('، ');
    }

    input.addEventListener('change', showFiles);

    ['dragenter', 'dragover'].forEach(event => {
        dropzone.addEventListener(event, e => {
            e.preventDefault();
            dropzone.classList.add('dragging');
        });
    });

    ['dragleave', 'drop'].forEach(event => {
        dropzone.addEventListener(event, e => {
            e.preventDefault();
            dropzone.classList.remove('dragging');
        });
    });

    dropzone.addEventListener('drop', e => {
        if (e.dataTransfer.files.length) {
            input.files = e.dataTransfer.files;
            showFiles();
        }
    });
}

const search = document.getElementById('fileSearch');

if (search) {
    search.addEventListener('input', () => {
        const query = search.value.toLowerCase();

        document.querySelectorAll('#fileRows tr').forEach(row => {
            row.style.display = row.innerText.toLowerCase().includes(query)
                ? ''
                : 'none';
        });
    });
}

function copyLink(path) {
    const url = new URL(path, window.location.href).href;

    navigator.clipboard.writeText(url)
        .then(() => showToast('لینک کپی شد!'))
        .catch(() => prompt('لینک فایل:', url));
}

function showToast(message) {
    const toast = document.getElementById('toast');
    if (!toast) return;

    toast.textContent = message;
    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
    }, 2500);
}
