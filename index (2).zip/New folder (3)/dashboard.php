$user = require_login();
$customMemory = $user['custom_memory'] ?? '';
<?php
require 'config.php';

$user = require_login();
$files = user_files($user['id']);

usort($files, function($a, $b) {
    return strcmp($b['uploaded_at'], $a['uploaded_at']);
});

$used = used_storage($user['id']);
$quota = max(1, (int)$user['quota']);
$percent = min(100, round(($used / $quota) * 100, 1));
$flashMessage = get_flash();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>داشبورد | Paya Upload Center</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>

<div class="app">

<aside class="sidebar">
    <a href="dashboard.php" class="logo">
        <span class="brand-icon small-logo">P</span>
        <span><b>Paya</b><small>UPLOAD CENTER</small></span>
    </a>

    <div class="side-title">فضای کاری</div>
    <a class="nav active" href="dashboard.php">▦ داشبورد</a>

    <?php if ($user['role'] === 'admin'): ?>
        <a class="nav" href="admin.php">⚙ مدیریت کاربران</a>
    <?php endif; ?>

    <div class="sidebar-user">
        <div class="avatar"><?=h(strtoupper(substr($user['username'], 0, 1)))?></div>
        <div>
            <b><?=h($user['username'])?></b>
            <small><?= $user['role'] === 'admin' ? 'مدیر سیستم' : 'کاربر' ?></small>
        </div>
        <a class="logout-icon" href="logout.php">↪</a>
    </div>
</aside>

<main class="main">

<header class="topbar">
    <div>
        <div class="eyebrow">PERSONAL CLOUD STORAGE</div>
        <h1>سلام، <?=h($user['username'])?> 👋</h1>
        <p class="muted">به فضای ذخیره‌سازی Paya خوش آمدی.</p>
    </div>
    <a class="btn outline" href="logout.php">خروج از حساب</a>
</header>

<?php if ($flashMessage): ?>
    <div class="alert <?=h($flashMessage[1])?>">
        <?=h($flashMessage[0])?>
    </div>
<?php endif; ?>

<section class="stats">

    <div class="stat-card">
        <div class="stat-icon purple">▤</div>
        <div class="stat-label">تعداد فایل‌ها</div>
        <div class="stat-value"><?=count($files)?></div>
        <div class="stat-foot">فایل فعال در حساب شما</div>
    </div>

    <div class="stat-card">
        <div class="stat-icon blue">⇧</div>
        <div class="stat-label">فضای مصرف‌شده</div>
        <div class="stat-value"><?=h(format_size($used))?></div>
        <div class="stat-foot">از <?=h(format_size($quota))?></div>
    </div>

    <div class="stat-card">
        <div class="stat-icon green">◉</div>
        <div class="stat-label">فضای باقی‌مانده</div>
        <div class="stat-value"><?=h(format_size(max(0, $quota - $used)))?></div>
        <div class="stat-foot">فضای آزاد حساب شما</div>
    </div>

</section>

<section class="grid-panels">

    <div class="panel">
        <div class="panel-heading">
            <div>
                <h2>فضای ذخیره‌سازی</h2>
                <p class="muted">میزان مصرف سهمیه شما</p>
            </div>
            <b class="percent"><?=h($percent)?>%</b>
        </div>

        <div class="progress">
            <span style="width:<?=$percent?>%"></span>
        </div>

        <div class="storage-info">
            <span><?=h(format_size($used))?> مصرف‌شده</span>
            <span><?=h(format_size($quota))?> کل فضا</span>
        </div>
    </div>

    <div class="panel">
        <div class="panel-heading">
            <div>
                <h2>آپلود فایل جدید</h2>
                <p class="muted">فایل‌هایت را به فضای ابری بفرست.</p>
            </div>
            <span class="upload-symbol">↑</span>
        </div>

        <form action="upload.php" method="post" enctype="multipart/form-data" id="uploadForm">
            <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">

            <label class="dropzone" id="dropzone">
                <input type="file" name="files[]" id="fileInput" multiple required>
                <span class="cloud-icon">☁</span>
                <b>برای انتخاب فایل کلیک کن</b>
                <small>یا فایل‌ها را اینجا بکش و رها کن</small>
                <em id="fileNames">حداکثر ۱۰۰ مگابایت برای هر فایل</em>
            </label>

            <button type="submit" class="btn primary full upload-button">
                آپلود فایل‌ها ↑
            </button>
        </form>
    </div>

</section>

<section class="panel files-panel" id="files">

    <div class="panel-heading">
        <div>
            <h2>فایل‌های من</h2>
            <p class="muted">مدیریت فایل‌های ذخیره‌شده</p>
        </div>

        <input id="fileSearch" class="search-input" placeholder="جستجوی فایل...">
    </div>

    <?php if (!$files): ?>

        <div class="empty">
            <div>☁</div>
            <b>هنوز فایلی آپلود نکرده‌ای</b>
            <p class="muted">اولین فایل خودت را آپلود کن.</p>
        </div>

    <?php else: ?>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>نام فایل</th>
                        <th>حجم</th>
                        <th>تاریخ</th>
                        <th>اشتراک‌گذاری</th>
                        <th>عملیات</th>
                    </tr>
                </thead>

                <tbody id="fileRows">
                <?php foreach ($files as $file): ?>
                    <tr>
                        <td>
                            <div class="file-name">
                                <span class="file-icon">FILE</span>
                                <b><?=h($file['original_name'])?></b>
                            </div>
                        </td>

                        <td><?=h(format_size($file['size']))?></td>

                        <td><?=h(date('Y/m/d H:i', strtotime($file['uploaded_at'])))?></td>

                        <td>
                            <button class="link-button"
                                onclick="copyLink('<?=h('share.php?token=' . $file['share_token'])?>')">
                                کپی لینک
                            </button>
                        </td>

                        <td>
                            <div class="actions">
                                <a href="download.php?id=<?=h($file['id'])?>">دانلود</a>

                                <form action="file_action.php" method="post"
                                    onsubmit="return confirm('این فایل حذف شود؟')">
                                    <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
                                    <input type="hidden" name="id" value="<?=h($file['id'])?>">
                                    <button name="action" value="delete" class="danger-button">حذف</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>

</section>

<footer class="footer">
    <span>Paya Upload Center</span>
    <span>Made with ♥ by Paya</span>
</footer>

</main>
</div>

<div id="toast" class="toast"></div>
<script src="assets/app.js"></script>
</body>
</html>
