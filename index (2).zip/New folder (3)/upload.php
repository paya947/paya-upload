
<?php
require 'config.php';

$user = require_login();
check_csrf();

if (empty($_FILES['files'])) {
    flash('هیچ فایلی انتخاب نشده است.', 'error');
    go('dashboard.php');
}

$allFiles = db_read('files');
$used = used_storage($user['id']);
$quota = (int)$user['quota'];

$success = 0;
$errors = [];

$names = $_FILES['files']['name'];
$total = count($names);

for ($i = 0; $i < $total; $i++) {

    $error = $_FILES['files']['error'][$i];

    if ($error === UPLOAD_ERR_NO_FILE) continue;

    if ($error !== UPLOAD_ERR_OK) {
        $errors[] = 'خطا در دریافت فایل: ' . $names[$i];
        continue;
    }

    $size = (int)$_FILES['files']['size'][$i];

    if ($size <= 0 || $size > MAX_FILE_SIZE) {
        $errors[] = 'حجم فایل نامعتبر است: ' . $names[$i];
        continue;
    }

    if ($used + $size > $quota) {
        $errors[] = 'سهمیه فضای ذخیره‌سازی کافی نیست.';
        break;
    }

    $original = basename($names[$i]);
    $original = preg_replace('/[\x00-\x1F\/\\\\]/u', '_', $original);

    $stored = bin2hex(random_bytes(24));
    $destination = FILES_DIR . '/' . $stored;

    if (!move_uploaded_file($_FILES['files']['tmp_name'][$i], $destination)) {
        $errors[] = 'ذخیره فایل ناموفق بود: ' . $original;
        continue;
    }

    $allFiles[] = [
        'id' => bin2hex(random_bytes(12)),
        'user_id' => $user['id'],
        'original_name' => $original,
        'stored_name' => $stored,
        'size' => $size,
        'share_token' => bin2hex(random_bytes(20)),
        'uploaded_at' => date('c'),
        'deleted' => false
    ];

    $used += $size;
    $success++;
}

db_write('files', $allFiles);

$message = $success . ' فایل با موفقیت آپلود شد.';

if ($errors) {
    $message .= ' ' . implode(' | ', $errors);
}

flash($message, $success ? 'success' : 'error');
go('dashboard.php');
