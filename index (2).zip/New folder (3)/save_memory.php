
<?php
require 'config.php';

$user = require_login();
check_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    go('dashboard.php');
}

$memory = trim($_POST['memory'] ?? '');

if (strlen($memory) > 10000) {
    flash('حافظه نمی‌تواند بیشتر از ۱۰ هزار بایت باشد.', 'error');
    go('dashboard.php#memory');
}

$users = db_read('users');
$found = false;

foreach ($users as &$u) {
    if ($u['id'] === $user['id']) {
        $u['custom_memory'] = $memory;
        $u['memory_updated_at'] = date('c');
        $found = true;
        break;
    }
}

unset($u);

if ($found) {
    db_write('users', $users);
    flash('حافظه اختصاصی شما ذخیره شد.');
} else {
    flash('ذخیره حافظه انجام نشد.', 'error');
}

go('dashboard.php#memory');
