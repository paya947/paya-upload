
<?php
require 'config.php';

if (current_user()) {
    go('dashboard.php');
}

go('login.php');
