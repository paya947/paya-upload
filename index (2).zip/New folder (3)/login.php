
<?php
require 'config.php';

if (current_user()) go('dashboard.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    foreach (db_read('users') as $user) {
        if (
            strtolower($user['username']) === strtolower($username) &&
            password_verify($password, $user['password'])
        ) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            go('dashboard.php');
        }
    }

    $error = 'نام کاربری یا رمز عبور اشتباه است.';
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ورود | Paya Upload Center</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="auth-page">
<div class="auth-card">
    <div class="brand-icon">P</div>
    <div class="eyebrow">PAYA CLOUD STORAGE</div>
    <h1>خوش برگشتی!</h1>
    <p class="muted">برای ورود به حساب خود اطلاعاتت را وارد کن.</p>

    <?php if ($error): ?>
        <div class="alert error"><?=h($error)?></div>
    <?php endif; ?>

    <?php if ($message = get_flash()): ?>
        <div class="alert <?=h($message[1])?>"><?=h($message[0])?></div>
    <?php endif; ?>

    <form method="post" class="form-stack">
        <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">

        <label>نام کاربری</label>
        <input name="username" required autocomplete="username" placeholder="نام کاربری">

        <label>رمز عبور</label>
        <input type="password" name="password" required autocomplete="current-password" placeholder="رمز عبور">

        <button class="btn primary full">ورود به حساب ←</button>
    </form>

    <div class="auth-bottom">
        حساب نداری؟ <a href="register.php">ثبت‌نام کن</a>
    </div>

    
</div>
</body>
</html>
