
<?php
session_start();

define('APP_NAME', 'Paya Upload Center');
define('DATA_DIR', __DIR__ . '/storage/data');
define('FILES_DIR', __DIR__ . '/storage/files');
define('MAX_FILE_SIZE', 100 * 1024 * 1024);
define('DEFAULT_QUOTA', 2 * 1024 * 1024 * 1024);

foreach ([DATA_DIR, FILES_DIR] as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

function db_read($name, $default = []) {
    $file = DATA_DIR . '/' . $name . '.json';
    if (!file_exists($file)) return $default;
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function db_write($name, $data) {
    $file = DATA_DIR . '/' . $name . '.json';
    $temp = $file . '.tmp';
    file_put_contents(
        $temp,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        LOCK_EX
    );
    rename($temp, $file);
}

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function format_size($bytes) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < 4) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 2) . ' ' . $units[$i];
}

function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function check_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf'] ?? '';
        if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
            http_response_code(419);
            exit('درخواست نامعتبر است. صفحه را تازه‌سازی کنید.');
        }
    }
}

function current_user() {
    if (empty($_SESSION['user_id'])) return null;

    foreach (db_read('users') as $user) {
        if ($user['id'] === $_SESSION['user_id']) return $user;
    }
    return null;
}

function require_login() {
    $user = current_user();
    if (!$user) {
        header('Location: login.php');
        exit;
    }
    return $user;
}

function user_files($userId) {
    return array_values(array_filter(db_read('files'), function($file) use ($userId) {
        return $file['user_id'] === $userId && empty($file['deleted']);
    }));
}

function used_storage($userId) {
    $total = 0;
    foreach (user_files($userId) as $file) {
        $total += (int)$file['size'];
    }
    return $total;
}

function flash($message, $type = 'success') {
    $_SESSION['flash'] = [$message, $type];
}

function get_flash() {
    $value = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $value;
}

function go($url) {
    header('Location: ' . $url);
    exit;
}

/* ایجاد مدیر اولیه */
if (!file_exists(DATA_DIR . '/users.json')) {
    db_write('users', [[
        'id' => bin2hex(random_bytes(12)),
        'username' => 'admin',
        'password' => password_hash('admin12345', PASSWORD_DEFAULT),
        'role' => 'admin',
        'quota' => DEFAULT_QUOTA,
        'created_at' => date('c')
    ]]);
}

if (!file_exists(DATA_DIR . '/files.json')) {
    db_write('files', []);
}

<section class="panel memory-panel" id="memory">

    <div class="panel-heading">
        <div>
            <h2>🧠 Custom Memory</h2>
            <p class="muted">
                حافظه اختصاصی حساب شما؛ اطلاعات دلخواهت را ذخیره کن.
            </p>
        </div>

        <span class="memory-badge">PRIVATE</span>
    </div>

    <form action="save_memory.php" method="post">

        <input type="hidden" name="csrf"
               value="<?=h(csrf_token())?>">

        <textarea
            name="memory"
            class="memory-input"
            maxlength="10000"
            placeholder="اینجا یادداشت‌ها، اطلاعات و متن‌های دلخواهت را بنویس..."><?=h($customMemory)?></textarea>

        <div class="memory-footer">
            <small>حداکثر ۱۰ هزار بایت</small>

            <button class="btn primary" type="submit">
                ذخیره حافظه ✓
            </button>
        </div>

    </form>

</section>

