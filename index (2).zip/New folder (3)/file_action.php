
<?php
require 'config.php';

$user = require_login();
check_csrf();

$id = $_POST['id'] ?? '';
$action = $_POST['action'] ?? '';

if ($action !== 'delete') {
    go('dashboard.php');
}

$files = db_read('files');
$found = false;

foreach ($files as &$file) {
    if (
        $file['id'] === $id &&
        $file['user_id'] === $user['id'] &&
        empty($file['deleted'])
    ) {
        $file['deleted'] = true;
        $file['deleted_at'] = date('c');
        $found = true;
        break;
    }
}

unset($file);
db_write('files', $files);

flash(
    $found ? 'فایل حذف شد.' : 'فایل پیدا نشد.',
    $found ? 'success' : 'error'
);

go('dashboard.php');
