
<?php
require 'config.php';

$user = require_login();
$id = $_GET['id'] ?? '';

foreach (db_read('files') as $file) {

    if (
        $file['id'] === $id &&
        $file['user_id'] === $user['id'] &&
        empty($file['deleted'])
    ) {
        $path = FILES_DIR . '/' . $file['stored_name'];

        if (!is_file($path)) break;

        header('Content-Type: application/octet-stream');
        header('Content-Length: ' . filesize($path));
        header(
            "Content-Disposition: attachment; filename*=UTF-8''" .
            rawurlencode($file['original_name'])
        );

        readfile($path);
        exit;
    }
}

http_response_code(404);
exit('فایل پیدا نشد.');
